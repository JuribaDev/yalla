// terminal.jsx — animated agent CLI terminal that drives the hero.
// Loops through: user prompt → agent reasoning → yalla CLI commands → success.
// speedMultiplier: 1 = normal, 0.5 = slow, 2 = fast.

const TerminalDemo = ({ speedMultiplier = 1 }) => {
  const [lines, setLines] = React.useState([]);
  const [typing, setTyping] = React.useState(null); // { text, kind }
  const bodyRef = React.useRef(null);

  const script = React.useMemo(() => ([
    { t: "chat", who: "user",
      text: "deploy this nextjs repo to prod, give it a postgres db and a domain. one shot." },
    { t: "pause", ms: 500 },
    { t: "chat", who: "agent",
      text: "On it. Reading the Yalla skills first, then I'll plan the deploy." },
    { t: "pause", ms: 350 },

    { t: "cmd", parts: [["$ ","c-prompt"],["yalla skills list ","c-cmd"],["--json","c-flag"]] },
    { t: "out", color: "c-dim", delay: 250,
      text: '["deploy","db.create","domain.attach","env.set","preview","rollback","logs","scale"]' },
    { t: "pause", ms: 250 },

    { t: "cmd", parts: [
      ["$ ","c-prompt"],
      ["yalla deploy ","c-cmd"],
      ["--git ","c-flag"], ["github.com/zaid/shop ","c-str"],
      ["--build ","c-flag"], ["nixpacks ","c-str"],
      ["--region ","c-flag"], ["jed-1 ","c-str"],
      ["--no-input ","c-flag"],
      ["--json","c-flag"],
    ]},
    { t: "out", color: "c-dim", delay: 350, text: "⟶ cloning repo…" },
    { t: "out", color: "c-dim", delay: 300, text: "⟶ detected · next.js 14.2 · node 22 · pnpm" },
    { t: "out", color: "c-dim", delay: 450, text: "⟶ building (nixpacks)  ████████████████  100%" },
    { t: "out", color: "c-ok",  delay: 250, text: "✓ build complete    12.3s" },
    { t: "pause", ms: 200 },

    { t: "cmd", parts: [
      ["$ ","c-prompt"],
      ["yalla db create ","c-cmd"],
      ["--type ","c-flag"], ["postgres ","c-str"],
      ["--plan ","c-flag"], ["sm ","c-str"],
      ["--backup ","c-flag"], ["daily","c-str"],
    ]},
    { t: "out", color: "c-ok", delay: 500,
      text: "✓ db.shop_prod provisioned · 1 vCPU · 1GB · jed-1" },
    { t: "pause", ms: 200 },

    { t: "cmd", parts: [
      ["$ ","c-prompt"],
      ["yalla domain attach ","c-cmd"],
      ["shop.yalla.sa ","c-str"],
      ["--cert ","c-flag"], ["auto","c-str"],
    ]},
    { t: "out", color: "c-dim", delay: 400, text: "⟶ DNS verified · TLS cert issued" },
    { t: "out", color: "c-ok",  delay: 200, text: "✓ live at https://shop.yalla.sa" },
    { t: "pause", ms: 500 },

    { t: "chat", who: "agent",
      text: "Done. Production is live. Postgres attached, daily backups on, cert auto-renews. Want a preview env for the next PR?" },
    { t: "pause", ms: 2400 },
    { t: "clear" },
  ]), []);

  React.useEffect(() => {
    let cancelled = false;
    const sleep = (ms) => new Promise((r) => setTimeout(r, Math.max(0, ms / speedMultiplier)));

    const typeStr = async (str, perChar, kind) => {
      let buf = "";
      for (let i = 0; i < str.length; i++) {
        if (cancelled) return;
        buf += str[i];
        setTyping({ text: buf, kind });
        await sleep(perChar);
      }
    };

    const run = async () => {
      while (!cancelled) {
        setLines([]);
        for (const step of script) {
          if (cancelled) return;
          if (step.t === "clear") { setLines([]); continue; }
          if (step.t === "pause") { await sleep(step.ms || 300); continue; }
          if (step.t === "chat") {
            await typeStr(step.text, step.who === "user" ? 18 : 13, "chat-" + step.who);
            if (cancelled) return;
            setTyping(null);
            setLines((l) => [...l, { t: "chat", who: step.who, text: step.text }]);
            continue;
          }
          if (step.t === "cmd") {
            const flat = step.parts.map(([s]) => s).join("");
            await typeStr(flat, 11, "cmd");
            if (cancelled) return;
            setTyping(null);
            setLines((l) => [...l, { t: "cmd", parts: step.parts }]);
            continue;
          }
          if (step.t === "out") {
            await sleep(step.delay || 200);
            if (cancelled) return;
            setLines((l) => [...l, { t: "out", color: step.color, text: step.text }]);
            continue;
          }
        }
      }
    };

    run();
    return () => { cancelled = true; };
  }, [script, speedMultiplier]);

  React.useEffect(() => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [lines, typing]);

  const renderLine = (ln, i) => {
    if (ln.t === "chat") {
      const isUser = ln.who === "user";
      return (
        <div key={i} style={{
          display: "flex", gap: 10, alignItems: "flex-start",
          margin: "8px 0", padding: "10px 12px",
          background: isUser ? "rgba(255,255,255,0.025)" : "rgba(0,196,122,0.05)",
          border: "1px solid " + (isUser ? "rgba(255,255,255,0.06)" : "rgba(0,196,122,0.18)"),
          borderRadius: 8,
          fontFamily: "var(--sans)",
          fontSize: 13.5,
          lineHeight: 1.5,
        }}>
          <span style={{
            fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em",
            color: isUser ? "var(--fg-3)" : "var(--accent)",
            textTransform: "uppercase", marginTop: 2, minWidth: 48,
          }}>{isUser ? "user" : "agent"}</span>
          <span style={{ color: "var(--fg)" }}>{ln.text}</span>
        </div>
      );
    }
    if (ln.t === "cmd") {
      return (
        <div key={i} className="term-line">
          {ln.parts.map(([txt, cls], j) => <span key={j} className={cls}>{txt}</span>)}
        </div>
      );
    }
    if (ln.t === "out") {
      return <div key={i} className={"term-line " + (ln.color || "c-dim")}>{ln.text}</div>;
    }
    return null;
  };

  const renderTyping = () => {
    if (!typing) return null;
    if (typing.kind && typing.kind.startsWith("chat-")) {
      const isUser = typing.kind === "chat-user";
      return (
        <div style={{
          display: "flex", gap: 10, alignItems: "flex-start",
          margin: "8px 0", padding: "10px 12px",
          background: isUser ? "rgba(255,255,255,0.025)" : "rgba(0,196,122,0.05)",
          border: "1px solid " + (isUser ? "rgba(255,255,255,0.06)" : "rgba(0,196,122,0.18)"),
          borderRadius: 8,
          fontFamily: "var(--sans)", fontSize: 13.5, lineHeight: 1.5,
        }}>
          <span style={{
            fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em",
            color: isUser ? "var(--fg-3)" : "var(--accent)",
            textTransform: "uppercase", marginTop: 2, minWidth: 48,
          }}>{isUser ? "user" : "agent"}</span>
          <span style={{ color: "var(--fg)" }}>
            {typing.text}<span className="cursor"></span>
          </span>
        </div>
      );
    }
    // cmd typing — show as raw text
    return (
      <div className="term-line">
        <span className="c-prompt">$ </span>
        <span className="c-cmd">{typing.text.replace(/^\$\s*/, "")}</span>
        <span className="cursor"></span>
      </div>
    );
  };

  return (
    <div className="term" style={{ width: "100%" }}>
      <div className="term-hd">
        <div className="term-dots"><i></i><i></i><i></i></div>
        <div className="term-title">agent ▸ ~/shop · yalla cli</div>
        <div className="pill" style={{ background: "transparent" }}>
          <span style={{
            width: 6, height: 6, borderRadius: 999,
            background: "var(--accent)", boxShadow: "0 0 6px var(--accent)",
            display: "inline-block"
          }}></span>
          live
        </div>
      </div>
      <div ref={bodyRef} className="term-body" style={{
        maxHeight: 480, overflowY: "auto",
        scrollbarWidth: "thin",
        scrollbarColor: "rgba(255,255,255,0.15) transparent",
      }}>
        {lines.map(renderLine)}
        {renderTyping()}
      </div>
    </div>
  );
};

Object.assign(window, { TerminalDemo });
