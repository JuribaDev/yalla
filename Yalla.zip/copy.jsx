// copy.jsx — small reusable copy-to-clipboard primitives

const CopyButton = ({ value, label = "copy", size = "sm", inline = false }) => {
  const [copied, setCopied] = React.useState(false);
  const onClick = (e) => {
    e.stopPropagation();
    e.preventDefault();
    try {
      navigator.clipboard.writeText(value);
    } catch (_) {
      // fallback
      const ta = document.createElement("textarea");
      ta.value = value; document.body.appendChild(ta);
      ta.select(); document.execCommand("copy"); ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };

  const dim = size === "sm";
  return (
    <button
      onClick={onClick}
      aria-label={"Copy " + label}
      className="copy-btn"
      style={{
        appearance: "none",
        display: "inline-flex", alignItems: "center", gap: 6,
        height: dim ? 24 : 28,
        padding: dim ? "0 8px" : "0 10px",
        border: "1px solid " + (copied ? "var(--accent-line)" : "var(--border-2)"),
        background: copied ? "var(--accent-soft)" : "rgba(255,255,255,0.04)",
        color: copied ? "var(--accent)" : "var(--fg-2)",
        borderRadius: 6,
        fontFamily: "var(--mono)", fontSize: 10.5,
        letterSpacing: "0.06em", textTransform: "uppercase",
        cursor: "pointer",
        transition: "color .15s, background .15s, border-color .15s",
        position: inline ? "static" : "absolute",
        right: inline ? "auto" : 10, top: inline ? "auto" : 10,
        zIndex: 2,
      }}
    >
      {copied ? (
        <>
          <svg width="10" height="10" viewBox="0 0 12 12" fill="none" style={{ color: "currentColor" }}>
            <path d="M2.5 6.2l2.4 2.4 5-5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          copied
        </>
      ) : (
        <>
          <svg width="10" height="10" viewBox="0 0 12 12" fill="none">
            <rect x="3.5" y="3.5" width="6" height="6" rx="1" stroke="currentColor" strokeWidth="1.1"/>
            <path d="M2.5 8V2.5h5.5" stroke="currentColor" strokeWidth="1.1" strokeLinecap="round"/>
          </svg>
          {label}
        </>
      )}
    </button>
  );
};

// CopyBlock — terminal-style block with one or more lines and a single copy button.
// lines: [{ prompt?, cmd, arg?, dim?, kind? }] OR a string (then rendered as plain code).
const CopyBlock = ({ lines, copyText, label, padded = true, dense = false }) => {
  const text = copyText || (Array.isArray(lines)
    ? lines.map(l => {
        if (typeof l === "string") return l;
        const p = l.prompt ? l.prompt + " " : "";
        const a = l.arg ? " " + l.arg : "";
        return p + (l.cmd || "") + a;
      }).join("\n")
    : String(lines || ""));

  return (
    <div style={{
      position: "relative",
      background: "#050505",
      border: "1px solid var(--border)",
      borderRadius: 10,
      padding: padded ? (dense ? "12px 14px" : "16px 18px") : 0,
      fontFamily: "var(--mono)", fontSize: 13, lineHeight: 1.65,
      direction: "ltr",
    }}>
      <CopyButton value={text} label={label || "copy"} />
      <div style={{ paddingRight: 60 }}>
        {Array.isArray(lines) ? lines.map((l, i) => {
          if (typeof l === "string") {
            return <div key={i} className="term-line" style={{ color: "var(--fg)" }}>{l}</div>;
          }
          if (l.kind === "ok") {
            return <div key={i} className="term-line c-ok" style={{ fontSize: 12.5 }}>{l.text}</div>;
          }
          if (l.kind === "spacer") return <div key={i} style={{ height: 8 }}></div>;
          return (
            <div key={i} className="term-line">
              {l.prompt && <span className="c-prompt">{l.prompt} </span>}
              <span className="c-cmd">{l.cmd}</span>
              {l.arg && <> <span className="c-str">{l.arg}</span></>}
              {l.dim && <span className="c-dim">  {l.dim}</span>}
            </div>
          );
        }) : <div className="term-line">{String(lines)}</div>}
      </div>
    </div>
  );
};

// InlineCopy — a thin inline pill with command + copy button. Used in hero.
const InlineCopy = ({ value, prompt = "$" }) => {
  return (
    <div style={{
      display: "inline-flex", alignItems: "center", gap: 12,
      padding: "8px 8px 8px 16px", direction: "ltr",
      background: "#050505",
      border: "1px solid var(--border)",
      borderRadius: 10,
      fontFamily: "var(--mono)", fontSize: 13.5,
      maxWidth: "100%",
    }}>
      <span className="c-prompt">{prompt}</span>
      <span className="c-cmd" style={{
        overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
      }}>{value}</span>
      <CopyButton value={value} inline />
    </div>
  );
};

Object.assign(window, { CopyButton, CopyBlock, InlineCopy });
