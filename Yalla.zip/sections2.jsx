// sections2.jsx — features grid, install, pricing, footer, and App composer

// ─── Features grid ─────────────────────────────────────────────────
const FeaturesSection = ({ t, c }) => {
  const isAr = t.lang === "ar";
  const features = isAr ? FEATURES_AR : FEATURES_EN;
  return (
    <section id="features" className="section">
      <div className="wrap">
        <div className={isAr ? "rtl" : ""} style={{ maxWidth: 720, marginBottom: 48 }}>
          <span className="eyebrow lang-body">{c.feat_eyebrow}</span>
          <h2 className="h1 lang-body" style={{ marginTop: 18 }}>{c.feat_title}</h2>
          <p className="lang-body" style={{ marginTop: 14, fontSize: 17 }}>{c.feat_sub}</p>
        </div>

        <div className="feat-grid">
          {features.map((f, i) => (
            <div key={f.t} className="feat lang-body">
              <div className="row between center">
                <span className="feat-num">{String(i + 1).padStart(2, "0")}</span>
                <span className="glyph">
                  <FeatureGlyph kind={f.icon} />
                </span>
              </div>
              <h3 className="lang-body">{f.t}</h3>
              <p className="lang-body">{f.d}</p>
              {f.tags && (
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginTop: 14 }}>
                  {f.tags.map(tg => (
                    <span key={tg} className="pill" style={{ fontSize: 10, height: 18, padding: "0 6px" }}>{tg}</span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const FEATURES_EN = [
  { t: "Application Deployments", d: "Web apps, APIs, workers, static sites, services — one workflow, one CLI.", icon: "ship", tags: ["web","api","worker","static"] },
  { t: "Preview Deployments",     d: "Isolated env per branch and PR. Share a URL, kill it on merge.", icon: "branch" },
  { t: "Database Provisioning",   d: "Postgres, MySQL, MariaDB, MongoDB, Redis — provisioned, connected, backed up.", icon: "db", tags: ["postgres","mysql","redis"] },
  { t: "Backups & Recovery",      d: "Daily schedules, manual snapshots, inspect & restore from any point.", icon: "backup" },
  { t: "Domains & HTTPS",         d: "Attach custom domains, auto TLS, manage certificates, ship safely.", icon: "globe" },
  { t: "Scaling & Health",        d: "Replicas, CPU, memory, health checks, deployment resources — all knobs.", icon: "scale" },
  { t: "Environment Management",  d: "Staging, production, previews. Secrets, runtime vars, build-time config.", icon: "env" },
  { t: "Persistent Storage",      d: "Volumes, bind mounts, file mounts for stateful workloads.", icon: "disk" },
  { t: "Scheduled Jobs",          d: "Cron, recurring background work, maintenance tasks — first-class.", icon: "clock" },
  { t: "CI / CD Workflows",       d: "Trigger redeploys from pipelines. JSON output, stable exits, safe to script.", icon: "ci" },
  { t: "Git Provider Support",    d: "GitHub, GitLab, Bitbucket, Gitea, any Git-compatible provider.", icon: "git" },
  { t: "Notifications",           d: "Deploy & infra events to team channels. Slack, Discord, webhooks.", icon: "bell" },
  { t: "Safe Production Ops",     d: "Redeploy, rollback, start, stop, restart, inspect logs — verify before you commit.", icon: "shield" },
];

const FEATURES_AR = [
  { t: "نشر التطبيقات",         d: "تطبيقات وب، APIs، عمّال، مواقع ثابتة، خدمات — تدفّق واحد، CLI واحد.", icon: "ship" },
  { t: "بيئات معاينة",          d: "بيئة معزولة لكل فرع وكل PR. شارك الرابط، واحذفها عند الدمج.", icon: "branch" },
  { t: "قواعد بيانات جاهزة",    d: "Postgres، MySQL، MariaDB، MongoDB، Redis — مُعدّة، مربوطة، ومحفوظة.", icon: "db" },
  { t: "نسخ احتياطي واستعادة", d: "جدولة يومية، لقطات يدوية، فحص واستعادة من أي نقطة.", icon: "backup" },
  { t: "النطاقات وHTTPS",       d: "اربط نطاقاتك، TLS تلقائي، إدارة الشهادات، انشر بأمان.", icon: "globe" },
  { t: "التوسعة والصحة",        d: "نسخ، CPU، ذاكرة، فحوص صحية، موارد النشر — كل المقابض.", icon: "scale" },
  { t: "إدارة البيئات",          d: "Staging وإنتاج ومعاينات. أسرار، متغيرات تشغيل، وضبط البناء.", icon: "env" },
  { t: "تخزين دائم",             d: "Volumes ونقاط ربط للملفات لتطبيقاتك ذات الحالة.", icon: "disk" },
  { t: "مهام مجدولة",            d: "Cron، مهام دورية في الخلفية، صيانة — مدعومة أساساً.", icon: "clock" },
  { t: "سير CI / CD",            d: "أعد النشر من خطوط الإنتاج. مخرجات JSON وأكواد خروج ثابتة.", icon: "ci" },
  { t: "دعم مزوّدي Git",         d: "GitHub، GitLab، Bitbucket، Gitea، وأي مزوّد متوافق.", icon: "git" },
  { t: "الإشعارات",              d: "أحداث النشر والبنية إلى قنوات فريقك. Slack، Discord، Webhooks.", icon: "bell" },
  { t: "عمليات إنتاج آمنة",      d: "أعد النشر، تراجع، شغّل، أوقف، أعد التشغيل، افحص السجلات.", icon: "shield" },
];

const FeatureGlyph = ({ kind }) => {
  const s = { width: 14, height: 14, stroke: "currentColor", fill: "none", strokeWidth: 1.6, color: "var(--accent)" };
  switch (kind) {
    case "ship":   return <svg {...s} viewBox="0 0 16 16"><rect x="2" y="3" width="12" height="9" rx="1.5"/><path d="M2 7h12"/><circle cx="5" cy="5" r=".5" fill="currentColor"/></svg>;
    case "branch": return <svg {...s} viewBox="0 0 16 16"><circle cx="4" cy="4" r="1.5"/><circle cx="4" cy="12" r="1.5"/><circle cx="12" cy="6" r="1.5"/><path d="M4 5.5v5M5.5 4h2.5a3 3 0 013 3v0"/></svg>;
    case "db":     return <svg {...s} viewBox="0 0 16 16"><ellipse cx="8" cy="4" rx="5" ry="2"/><path d="M3 4v4c0 1.1 2.24 2 5 2s5-.9 5-2V4"/><path d="M3 8v4c0 1.1 2.24 2 5 2s5-.9 5-2V8"/></svg>;
    case "backup": return <svg {...s} viewBox="0 0 16 16"><path d="M3 8a5 5 0 1 0 1.5-3.5"/><path d="M3.2 4v3h3"/></svg>;
    case "globe":  return <svg {...s} viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.5"/><path d="M2.5 8h11M8 2.5c2 2.5 2 8.5 0 11M8 2.5c-2 2.5-2 8.5 0 11"/></svg>;
    case "scale":  return <svg {...s} viewBox="0 0 16 16"><path d="M2 13l4-4 3 3 5-5"/><path d="M10 7h4v4"/></svg>;
    case "env":    return <svg {...s} viewBox="0 0 16 16"><rect x="2" y="3" width="12" height="10" rx="1.5"/><path d="M2 6h12M5 9h3M5 11h2"/></svg>;
    case "disk":   return <svg {...s} viewBox="0 0 16 16"><rect x="2.5" y="2.5" width="11" height="11" rx="1.5"/><circle cx="8" cy="8" r="2.5"/><circle cx="8" cy="8" r=".6" fill="currentColor"/></svg>;
    case "clock":  return <svg {...s} viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.5"/><path d="M8 5v3l2 2"/></svg>;
    case "ci":     return <svg {...s} viewBox="0 0 16 16"><circle cx="4" cy="4" r="1.5"/><circle cx="12" cy="4" r="1.5"/><circle cx="8" cy="12" r="1.5"/><path d="M4 5.5V7a2 2 0 002 2h4a2 2 0 002-2V5.5"/><path d="M8 9v1.5"/></svg>;
    case "git":    return <svg {...s} viewBox="0 0 16 16"><circle cx="8" cy="8" r="5.5"/><path d="M5 8h6M8 5v6"/></svg>;
    case "bell":   return <svg {...s} viewBox="0 0 16 16"><path d="M4 11h8l-1-2V7a3 3 0 10-6 0v2l-1 2z"/><path d="M7 13a1 1 0 002 0"/></svg>;
    case "shield": return <svg {...s} viewBox="0 0 16 16"><path d="M8 2l5 1.5v4.5c0 3-2.2 5-5 6-2.8-1-5-3-5-6V3.5L8 2z"/><path d="M6 8l1.5 1.5L10 7"/></svg>;
    default: return null;
  }
};

// ─── Install ──────────────────────────────────────────────────────────
const InstallSection = ({ t, c }) => {
  const isAr = t.lang === "ar";

  return (
    <section id="cli" className="section" style={{ paddingTop: 40 }}>
      <div className="wrap">
        <div className={isAr ? "rtl" : ""} style={{ textAlign: "center", marginBottom: 36 }}>
          <span className="eyebrow lang-body">{c.install_eyebrow}</span>
          <h2 className="h1 lang-body" style={{ marginTop: 18 }}>{c.install_title}</h2>
          <p className="lang-body" style={{ marginTop: 12, fontSize: 16, maxWidth: 540, margin: "12px auto 0" }}>
            {c.install_copy}
          </p>
        </div>

        <div style={{ maxWidth: 880, margin: "0 auto", display: "grid", gap: 14 }}>
          {/* Step 1 — install */}
          <InstallStep n="01" title={isAr ? "ثبّت الـCLI" : "Install the CLI"}
            sub={isAr ? "عبر npm — يعمل على ماك، لينكس، وويندوز." : "One package. Works on macOS, Linux, and Windows."}
            badge="npm">
            <CopyBlock label="install" lines={[
              { prompt: "$", cmd: "npm install -g", arg: "@juriba/yalla-cli" },
              { prompt: "$", cmd: "yalla --version", dim: (isAr ? "# تأكّد" : "# verify") },
            ]} />
          </InstallStep>

          {/* Step 2 — login */}
          <InstallStep n="02" title={isAr ? "سجّل الدخول" : "Authenticate"}
            sub={isAr ? "اربط الـCLI بحسابك في يلا." : "Hook the CLI up to your Yalla account."}
            badge="auth">
            <CopyBlock label="login" lines={[
              { prompt: "$", cmd: "yalla auth login" },
            ]} />
            <div style={{
              padding: "12px 14px",
              border: "1px dashed var(--border-2)", borderRadius: 8,
              background: "rgba(255,255,255,0.02)",
              fontFamily: "var(--mono)", fontSize: 12.5, lineHeight: 1.85,
              direction: "ltr",
              display: "grid", gap: 6,
            }}>
              <FieldRow
                label="URL"
                value="https://ploy.jsa.sa"
                color="c-str"
              />
              <FieldRow
                label="API token"
                value="yalla_•••••••••••••••••••••••"
                copyValue=""
                placeholder
              />
            </div>
          </InstallStep>

          {/* Step 3 — agent skills */}
          <InstallStep n="03" title={isAr ? "ركّب مهارات الوكيل" : "Install agent skills"}
            sub={isAr ? "أضف سوق المهارات، ثم ركّب مهارة النشر." : "Add the marketplace, then install the deploy skill."}
            badge="skills" accent>
            <CopyBlock label="marketplace" lines={[
              { cmd: "/plugin marketplace add", arg: "JuribaDev/yalla-skills" },
              { kind: "ok", text: "✓ marketplace added: yalla-skills" },
            ]} />
            <CopyBlock label="skill" lines={[
              { cmd: "/plugin install", arg: "yalla-dokploy-deploy@yalla-skills" },
              { kind: "ok", text: "✓ skill ready · yalla-dokploy-deploy" },
            ]} />
          </InstallStep>

          {/* Step 4 — ship */}
          <InstallStep n="04" title={isAr ? "اطلق وكيلك" : "Hand it to your agent"}
            sub={isAr ? "أمرٌ واحد، وأنت في الإنتاج." : "One prompt. You're in production."}
            badge="ship" final>
            <div style={{
              position: "relative",
              padding: "16px 18px", borderRadius: 8,
              background: "rgba(255,255,255,0.04)",
              border: "1px solid var(--border-2)",
              fontFamily: "var(--sans)", fontSize: 14.5, lineHeight: 1.55, color: "var(--fg)",
            }}>
              <CopyButton
                value={isAr
                  ? "انشر هذا المشروع للإنتاج، أضف postgres، واربط نطاق."
                  : "Deploy this repo to prod, add postgres, attach a domain."}
                label="copy"
              />
              <span style={{
                fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em",
                color: "var(--fg-3)", textTransform: "uppercase", marginRight: 10,
              }}>you</span>
              <span style={{ paddingRight: 70, display: "inline-block" }}>
                {isAr
                  ? "انشر هذا المشروع للإنتاج، أضف postgres، واربط نطاق."
                  : "Deploy this repo to prod, add postgres, attach a domain."}
              </span>
            </div>
          </InstallStep>
        </div>

        <div style={{
          marginTop: 22, textAlign: "center",
          fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--fg-3)",
        }}>
          <span>macOS · Linux · Windows</span>
          <span style={{ margin: "0 12px", color: "var(--fg-4)" }}>·</span>
          <span>arm64 · x86_64</span>
          <span style={{ margin: "0 12px", color: "var(--fg-4)" }}>·</span>
          <span>node ≥ 18</span>
        </div>
      </div>
    </section>
  );
};

const InstallStep = ({ n, title, sub, badge, accent, final, children }) => (
  <div className="card install-card" style={{
    padding: 0, overflow: "hidden",
    display: "grid", gridTemplateColumns: "minmax(220px, 280px) 1fr",
    background: accent || final
      ? "linear-gradient(90deg, rgba(255,255,255,0.04), var(--bg-1))"
      : "var(--bg-1)",
    borderColor: accent ? "var(--border-2)" : "var(--border)",
  }}>
    <div style={{
      padding: "22px 24px",
      borderRight: "1px solid var(--border)",
      display: "flex", flexDirection: "column", justifyContent: "space-between",
    }}>
      <div>
        <div className="row between center" style={{ marginBottom: 14 }}>
          <span style={{
            fontFamily: "var(--mono)", fontSize: 11, letterSpacing: "0.08em",
            color: "var(--fg-3)",
          }}>STEP {n}</span>
          <span className="pill" style={{
            color: accent ? "var(--accent)" : "var(--fg-2)",
            borderColor: accent ? "var(--accent-line)" : "var(--border-2)",
            background: accent ? "var(--accent-soft)" : "rgba(255,255,255,0.04)",
          }}>{badge}</span>
        </div>
        <h3 className="lang-body" style={{ fontSize: 18, letterSpacing: "-0.01em" }}>{title}</h3>
        <p className="lang-body" style={{ marginTop: 6, fontSize: 13, color: "var(--fg-2)" }}>{sub}</p>
      </div>
    </div>
    <div style={{
      padding: 18,
      background: "var(--bg)",
      display: "flex", flexDirection: "column", gap: 10,
      minHeight: 96,
    }}>
      {children}
    </div>
    <style>{`
      @media (max-width: 760px) {
        .install-card { grid-template-columns: 1fr !important; }
        .install-card > div:first-child { border-right: 0 !important; border-bottom: 1px solid var(--border); }
      }
    `}</style>
  </div>
);

const FieldRow = ({ label, value, placeholder }) => (
  <div style={{
    display: "flex", alignItems: "center", justifyContent: "space-between", gap: 10,
  }}>
    <div style={{ display: "flex", alignItems: "baseline", gap: 10, minWidth: 0 }}>
      <span style={{
        color: "var(--fg-3)", fontSize: 11, letterSpacing: "0.06em",
        textTransform: "uppercase", minWidth: 76, flexShrink: 0,
      }}>{label}</span>
      <span style={{
        color: placeholder ? "var(--fg-3)" : "var(--accent)",
        fontFamily: "var(--mono)", fontSize: 12.5,
        overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap",
      }}>{value}</span>
    </div>
    {!placeholder && (
      <CopyButton value={value} inline />
    )}
  </div>
);

// ─── Pricing ──────────────────────────────────────────────────────────
const PricingSection = ({ t, c }) => {
  const isAr = t.lang === "ar";
  const tiers = isAr ? [
    { name: "هاوي", price: "مجاناً", desc: "للأفراد والمشاريع الجانبية. للأبد.",
      features: ["مشروعان نشطان","بيئة معاينة","قاعدة بيانات صغيرة","CLI و JSON كامل","نسخ احتياطي يومي"],
      cta: "ابدأ مجاناً", primary: false },
    { name: "محترف", price: "ادفع كما تستخدم", desc: "للوكلاء والفرق المنطلقة.",
      features: ["مشاريع لا محدودة","نشر معاينات بلا حصص","قواعد بيانات بأي حجم","التوسعة، المهام، التخزين","دعم سريع · 99.95٪"],
      cta: "ارفع لمحترف", primary: true, tag: "موصى به" },
    { name: "مؤسسة", price: "تواصل", desc: "لمؤسسات تشغل أعمالها على يلا.",
      features: ["SSO، RBAC، تدقيق","مناطق خاصة","SLA مخصّصة","نسخ احتياطي متعدد المواقع","فاتورة سنوية بالريال"],
      cta: "تواصل معنا", primary: false },
  ] : [
    { name: "Hobby", price: "Free", desc: "For solo devs and side projects. Forever.",
      features: ["2 active projects","Preview deployments","Small Postgres","Full CLI + JSON","Daily backups"],
      cta: "Start free", primary: false },
    { name: "Pro", price: "Pay-as-you-go", desc: "For agents and teams shipping fast.",
      features: ["Unlimited projects","Unlimited preview deploys","Databases any size","Scaling, jobs, storage","Priority support · 99.95%"],
      cta: "Go Pro", primary: true, tag: "Recommended" },
    { name: "Enterprise", price: "Talk to us", desc: "For orgs running production on Yalla.",
      features: ["SSO, RBAC, audit","Private regions","Custom SLAs","Multi-region backups","Annual billing in SAR"],
      cta: "Contact sales", primary: false },
  ];

  return (
    <section id="pricing" className="section">
      <div className="wrap">
        <div className={isAr ? "rtl" : ""} style={{ maxWidth: 720, marginBottom: 48 }}>
          <span className="eyebrow lang-body">{c.pricing_eyebrow}</span>
          <h2 className="h1 lang-body" style={{ marginTop: 18 }}>{c.pricing_title}</h2>
          <p className="lang-body" style={{ marginTop: 12, fontSize: 17 }}>{c.pricing_sub}</p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 14 }} className="price-grid">
          {tiers.map(tier => (
            <div key={tier.name} className="card lang-body" style={{
              padding: 28,
              borderColor: tier.primary ? "var(--accent-line)" : "var(--border)",
              background: tier.primary
                ? "radial-gradient(ellipse 100% 60% at 50% 0%, rgba(0,196,122,0.10), var(--bg-1))"
                : "var(--bg-1)",
              position: "relative",
            }}>
              {tier.tag && (
                <span style={{
                  position: "absolute", top: 16, right: 16,
                  fontFamily: "var(--mono)", fontSize: 10, letterSpacing: "0.08em",
                  color: "var(--accent)", textTransform: "uppercase",
                  background: "rgba(0,196,122,0.1)", padding: "3px 8px",
                  border: "1px solid var(--accent-line)", borderRadius: 999,
                }}>{tier.tag}</span>
              )}
              <h3 style={{ fontSize: 18 }}>{tier.name}</h3>
              <div style={{ marginTop: 18, fontSize: 30, fontWeight: 600, letterSpacing: "-0.02em" }}>{tier.price}</div>
              <p style={{ marginTop: 6, fontSize: 13.5 }}>{tier.desc}</p>
              <hr className="hr-dot" style={{ margin: "22px 0" }} />
              <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 10 }}>
                {tier.features.map(f => (
                  <li key={f} style={{ display: "flex", gap: 10, alignItems: "center", fontSize: 13.5, color: "var(--fg-2)" }}>
                    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ color: "var(--accent)", flexShrink: 0 }}>
                      <path d="M2.5 6.2l2.4 2.4 5-5" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                    {f}
                  </li>
                ))}
              </ul>
              <a href="#" className={"btn " + (tier.primary ? "btn-primary" : "btn-ghost")} style={{ marginTop: 24, width: "100%", justifyContent: "center" }}>
                {tier.cta}
              </a>
            </div>
          ))}
        </div>
      </div>
      <style>{`
        @media (max-width: 900px) {
          .price-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </section>
  );
};

// ─── CTA + Footer ─────────────────────────────────────────────────────
const FooterCTA = ({ t, c }) => {
  const isAr = t.lang === "ar";
  return (
    <section className="section" style={{ paddingTop: 60 }}>
      <div className="wrap">
        <div style={{
          padding: "64px 48px",
          border: "1px solid var(--border-2)",
          borderRadius: 20,
          background:
            "radial-gradient(ellipse 100% 80% at 50% 0%, rgba(0,196,122,0.12), transparent 70%), " +
            "linear-gradient(180deg, var(--bg-2), var(--bg-1))",
          textAlign: "center", position: "relative", overflow: "hidden",
        }}>
          <div style={{
            position: "absolute", inset: 0,
            backgroundImage:
              "linear-gradient(to right, rgba(255,255,255,0.04) 1px, transparent 1px)," +
              "linear-gradient(to bottom, rgba(255,255,255,0.04) 1px, transparent 1px)",
            backgroundSize: "48px 48px",
            mask: "radial-gradient(ellipse 80% 60% at 50% 50%, black 30%, transparent 80%)",
            pointerEvents: "none",
          }}></div>
          <div style={{ position: "relative" }}>
            <img
              src="assets/logo.png"
              alt="Yalla"
              style={{
                height: 84, width: "auto", display: "inline-block",
                filter: "drop-shadow(0 0 24px rgba(255,255,255,0.12))",
              }}
            />
            <h2 className="h1 lang-body" style={{ marginTop: 16, maxWidth: 720, marginInline: "auto" }}>
              {isAr ? "أمرٌ واحد، وأنت في الإنتاج." : "One prompt away from production."}
            </h2>
            <p className="lang-body" style={{ marginTop: 14, color: "var(--fg-2)", fontSize: 16 }}>
              {isAr ? "ابدأ مجاناً. أنشر في الثواني." : "Free to start. Ship in seconds."}
            </p>
            <div className="row gap-12 lang-body" style={{ justifyContent: "center", marginTop: 28, flexWrap: "wrap" }}>
              <a href="#" className="btn btn-primary">{c.cta_primary} →</a>
              <a href="#cli" className="btn btn-ghost">
                <span className="mono" style={{ fontSize: 13 }}>$</span> npm i -g @juriba/yalla-cli
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = ({ t, c }) => {
  const isAr = t.lang === "ar";
  return (
    <footer>
      <div className="wrap">
        <div className="foot-grid lang-body">
          <div>
            <Wordmark />
            <p style={{ marginTop: 14, fontSize: 13.5, color: "var(--fg-2)", maxWidth: 320 }}>
              {isAr
                ? "منصة النشر المبنية لوكلاء الذكاء الاصطناعي. صُنعت في الرياض."
                : "The AI-first deployment platform. Built in Riyadh, made for the world."}
            </p>
            <p className="mono" style={{ fontSize: 11, color: "var(--accent)", marginTop: 20, letterSpacing: "0.05em" }}>
              {c.footer_tag}
            </p>
          </div>
          <div>
            <h5>Product</h5>
            <a href="#">{c.nav.features}</a>
            <a href="#">{c.nav.cli}</a>
            <a href="#">{c.nav.pricing}</a>
            <a href="#">Changelog</a>
          </div>
          <div>
            <h5>Developers</h5>
            <a href="#">Docs</a>
            <a href="#">CLI Reference</a>
            <a href="#">Skills API</a>
            <a href="#">Status</a>
          </div>
          <div>
            <h5>Company</h5>
            <a href="#">About</a>
            <a href="#">Careers</a>
            <a href="#">Press</a>
            <a href="#">Contact</a>
          </div>
          <div>
            <h5>Resources</h5>
            <a href="#">Guides</a>
            <a href="#">Templates</a>
            <a href="#">Community</a>
            <a href="#">Discord</a>
          </div>
        </div>
        <div style={{
          marginTop: 56, paddingTop: 22, borderTop: "1px solid var(--border)",
          display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 12,
          fontFamily: "var(--mono)", fontSize: 11.5, color: "var(--fg-3)",
        }}>
          <span>© 2026 Yalla, Inc. · Riyadh, Saudi Arabia</span>
          <span className="row gap-16">
            <span>Privacy</span>
            <span>Terms</span>
            <span>Security</span>
            <span style={{ color: "var(--accent)" }}>● jed-1 operational</span>
          </span>
        </div>
      </div>
    </footer>
  );
};

Object.assign(window, { FeaturesSection, InstallSection, PricingSection, FooterCTA, Footer });
