// app.jsx — Yalla landing page

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": ["#f5f5f4", "#a3a3a3", "#0a0a0a"],
  "accentName": "Mono",
  "fontPair": "geist",
  "lang": "en",
  "density": "regular",
  "heroCopy": "default",
  "demoSpeed": 1,
  "showAgent": true,
  "showBuilds": true,
  "showSchema": true,
  "showFeatures": true,
  "showInstall": true,
  "showPricing": true
}/*EDITMODE-END*/;

// ─── Palettes ─────────────────────────────────────────────────────────
const PALETTES = {
  "Mono":         ["#f5f5f4", "#a3a3a3", "#0a0a0a"],
  "Saudi green":  ["#00c47a", "#00a364", "#001a10"],
  "Desert amber": ["#ffb454", "#d68a2c", "#1c1208"],
  "Riyadh sky":   ["#67e8f9", "#22d3ee", "#04181c"],
  "Najd violet":  ["#a78bfa", "#7c5aed", "#0e0820"],
  "Hejaz rose":   ["#fb7185", "#e11d48", "#1a0810"],
};

// ─── Copy ─────────────────────────────────────────────────────────────
const COPY = {
  en: {
    nav: { features: "Features", agents: "For Agents", docs: "Docs", pricing: "Pricing", cli: "CLI" },
    cta_primary: "Start shipping",
    cta_secondary: "Read the docs",
    eyebrow: "Made in Saudi · Built for AI agents",
    hero_kicker: "يلا · let's go",
    headlines: {
      default:   { a: "One prompt.", b: "Live in seconds." },
      speed:     { a: "Deploy at the", b: "speed of thought." },
      agents:    { a: "The deploy platform", b: "built for agents." },
      bilingual: { a: "يلا — ship it.", b: "Your agent already knows how." },
    },
    sub_default: "Yalla is an AI-first deployment platform. Your agent runs one CLI, and your app, database, domain, and pipeline are live — no console clicks, no YAML rituals.",
    install_copy: "Install on macOS, Linux, or Windows. Then let your agent take it from there.",
    agents_eyebrow: "AI · CLI · Skills",
    agents_title: "The CLI your agent was waiting for.",
    agents_sub: "Yalla CLI ships with Skills — small, structured capabilities the agent can discover and call. Stable exit codes, JSON output, no-input mode. The agent never has to guess.",
    skills_title: "Skills, not flags-soup",
    skills_body: "yalla skills list returns every capability with its schema. Your agent picks the right skill and fills in fields — no scraping help text.",
    json_title: "JSON in, JSON out",
    json_body: "Every command supports --json. Errors are typed. Exit codes are stable. Pipelines and agents read it the same way.",
    schema_title: "Self-describing platform",
    schema_body: "Ask the CLI what it can do — including required args, enums, regions, and error codes. The platform is the docs.",
    builds_eyebrow: "Ship anything",
    builds_title: "Bring your stack.",
    builds_sub: "Yalla detects what you've got and builds it. Web apps, APIs, workers, static sites, cron jobs — one workflow.",
    feat_eyebrow: "The full kit",
    feat_title: "Production-grade, end to end.",
    feat_sub: "Everything you'd build on a PaaS — without the console safari.",
    install_eyebrow: "Install in 10 seconds",
    install_title: "One CLI. Every platform.",
    pricing_eyebrow: "Pricing",
    pricing_title: "Pay for what you ship.",
    pricing_sub: "Free for solo. Pay-as-you-go beyond. No seats, no surprise lock-ins.",
    footer_tag: "Built in Riyadh · يلا نطلق",
  },
  ar: {
    nav: { features: "المزايا", agents: "للوكلاء", docs: "الوثائق", pricing: "الأسعار", cli: "الـCLI" },
    cta_primary: "ابدأ النشر",
    cta_secondary: "اقرأ الوثائق",
    eyebrow: "صُنع في السعودية · مبني لوكلاء الذكاء",
    hero_kicker: "يلا · انطلق",
    headlines: {
      default:   { a: "أمرٌ واحد.", b: "وتطبيقك مباشر." },
      speed:     { a: "انشر بسرعة", b: "الفكرة." },
      agents:    { a: "منصة النشر", b: "المبنية للوكلاء." },
      bilingual: { a: "يلا — انشرها.", b: "وكيلك يعرف الباقي." },
    },
    sub_default: "يلا منصة نشر تُركّز على الذكاء الاصطناعي. وكيلك ينفّذ أمراً واحداً في الـCLI، ويصبح تطبيقك وقاعدة بياناتك ونطاقك جاهزاً للإنتاج — دون نقرات أو ملفات YAML.",
    install_copy: "ثبّت الأداة على ماك أو لينكس أو ويندوز، ثم اترك الوكيل يتولّى البقية.",
    agents_eyebrow: "ذكاء · CLI · مهارات",
    agents_title: "الـCLI الذي ينتظره وكيلك.",
    agents_sub: "يلا CLI يأتي بـ«مهارات» منظّمة يستطيع الوكيل اكتشافها واستدعاءها. أكواد خروج ثابتة، مخرجات JSON، ووضع بلا تفاعل. لا يخمّن الوكيل أبداً.",
    skills_title: "مهارات، لا فوضى أعلام",
    skills_body: "yalla skills list يُرجع كل قدرة مع مخطّطها. الوكيل يختار المهارة الصحيحة ويملأ الحقول — دون قراءة نصوص المساعدة.",
    json_title: "JSON دخولاً وخروجاً",
    json_body: "كل أمر يدعم ‎--json. الأخطاء مُصنّفة، وأكواد الخروج ثابتة. خطوط التنفيذ والوكلاء يقرأونها بنفس الطريقة.",
    schema_title: "منصة تصف نفسها",
    schema_body: "اسأل الـCLI عمّا يستطيع فعله — الحقول الإلزامية، الخيارات، المناطق، وأكواد الخطأ. المنصّة هي التوثيق.",
    builds_eyebrow: "انشر أي شيء",
    builds_title: "أحضِر تقنيتك.",
    builds_sub: "يلا يكتشف ما لديك ويبني له. تطبيقات وب، واجهات APIs، عمّال، مواقع ثابتة، مهام مجدولة — في تدفّق واحد.",
    feat_eyebrow: "العدّة كاملة",
    feat_title: "بمستوى الإنتاج، من البداية للنهاية.",
    feat_sub: "كل ما تحتاجه في منصة كخدمة — دون تيه بين الشاشات.",
    install_eyebrow: "ثبّت في عشر ثوانٍ",
    install_title: "CLI واحد. لكل نظام.",
    pricing_eyebrow: "الأسعار",
    pricing_title: "ادفع مقابل ما تنشره.",
    pricing_sub: "مجاني للأفراد. ادفع كما تستخدم بعد ذلك. بلا مقاعد، بلا حبس.",
    footer_tag: "صُنع في الرياض · يلا نطلق",
  },
};

// ─── Wordmark ─────────────────────────────────────────────────────────
const Wordmark = ({ size = 32 }) => (
  <span className="wordmark" style={{ display: "inline-flex", alignItems: "center" }}>
    <img
      src="assets/logo.png"
      alt="Yalla"
      style={{
        height: size,
        width: "auto",
        display: "block",
        filter: "drop-shadow(0 0 12px rgba(255,255,255,0.08))",
      }}
    />
  </span>
);

// ─── Nav ──────────────────────────────────────────────────────────────
const Nav = ({ c }) => (
  <div className="nav-wrap">
    <div className="wrap nav">
      <div className="nav-left">
        <Wordmark />
        <div className="nav-links">
          <a href="#features">{c.nav.features}</a>
          <a href="#agents">{c.nav.agents}</a>
          <a href="#cli">{c.nav.cli}</a>
          <a href="#pricing">{c.nav.pricing}</a>
          <a href="#docs">{c.nav.docs}</a>
        </div>
      </div>
      <div className="row gap-12">
        <a className="btn btn-link" href="#">Sign in</a>
        <a className="btn btn-primary" href="#">{c.cta_primary} →</a>
      </div>
    </div>
  </div>
);

// ─── Hero ─────────────────────────────────────────────────────────────
const Hero = ({ t, c }) => {
  const head = c.headlines[t.heroCopy] || c.headlines.default;
  const isAr = t.lang === "ar";
  return (
    <section className="section" style={{ paddingTop: 64, paddingBottom: 80, position: "relative", overflow: "hidden" }}>
      <div className="hero-glow"></div>
      <div className="gridbg"></div>
      <div className="wrap" style={{ position: "relative", zIndex: 1 }}>
        <div className="split-grid split-hero">
          <div className={isAr ? "rtl" : ""}>
            <span className="eyebrow lang-body">{c.eyebrow}</span>
            <h1 className="h-display lang-body" style={{ marginTop: 24 }}>
              <span style={{ display: "block" }}>{head.a}</span>
              <span style={{ display: "block", color: "var(--accent)" }}>{head.b}</span>
            </h1>
            <p className="lang-body" style={{
              marginTop: 22, fontSize: 17.5, lineHeight: 1.5, color: "var(--fg-2)",
              maxWidth: 540,
            }}>
              {c.sub_default}
            </p>

            <div className="row gap-12 lang-body" style={{ marginTop: 32, flexWrap: "wrap" }}>
              <a className="btn btn-primary" href="#">
                {c.cta_primary} <span style={{ opacity: 0.6 }}>→</span>
              </a>
              <a className="btn btn-ghost" href="#">
                <span className="mono" style={{ fontSize: 13 }}>$</span> {c.cta_secondary}
              </a>
            </div>

            <div style={{ marginTop: 36 }}>
              <InlineCopy value="npm install -g @juriba/yalla-cli" />
            </div>

            <div className="row gap-16 lang-body" style={{ marginTop: 32, color: "var(--fg-3)", fontSize: 12 }}>
              <span style={{ fontFamily: "var(--mono)", letterSpacing: "0.06em", textTransform: "uppercase" }}>
                ── {isAr ? "متوافق مع" : "speaks fluent"}
              </span>
              <BrandChip>Claude</BrandChip>
              <BrandChip>Cursor</BrandChip>
              <BrandChip>Codex</BrandChip>
              <BrandChip>Gemini CLI</BrandChip>
            </div>
          </div>

          <div style={{ direction: "ltr" }}>
            <TerminalDemo speedMultiplier={t.demoSpeed} />
          </div>
        </div>
      </div>
    </section>
  );
};

const BrandChip = ({ children }) => (
  <span style={{
    fontFamily: "var(--mono)", fontSize: 12, color: "var(--fg-2)",
    padding: "3px 8px", border: "1px solid var(--border)", borderRadius: 6,
    background: "rgba(255,255,255,0.02)",
  }}>{children}</span>
);

Object.assign(window, { Wordmark, Nav, Hero, BrandChip });
