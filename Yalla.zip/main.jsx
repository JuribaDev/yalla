// main.jsx — App composer, Tweaks panel, and mount

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const c = COPY[t.lang] || COPY.en;
  const isAr = t.lang === "ar";

  // apply tweaks → CSS variables on <html>
  React.useEffect(() => {
    const root = document.documentElement;
    const [a] = t.palette || PALETTES["Mono"];
    root.style.setProperty("--accent", a);
    root.style.setProperty("--accent-soft", hexToRgba(a, 0.12));
    root.style.setProperty("--accent-line", hexToRgba(a, 0.34));

    root.setAttribute("data-density", t.density || "regular");
    root.setAttribute("data-lang", t.lang || "en");
    root.setAttribute("dir", isAr ? "rtl" : "ltr");

    // font swap
    const fontMap = {
      geist:  { sans: '"Geist", ui-sans-serif, system-ui, sans-serif', mono: '"Geist Mono", ui-monospace, monospace' },
      mono:   { sans: '"Geist Mono", ui-monospace, monospace',         mono: '"Geist Mono", ui-monospace, monospace' },
      arabic: { sans: '"Reem Kufi Fun", "IBM Plex Sans Arabic", sans-serif', mono: '"Geist Mono", ui-monospace, monospace' },
    };
    const f = fontMap[t.fontPair] || fontMap.geist;
    root.style.setProperty("--sans", f.sans);
    root.style.setProperty("--mono", f.mono);
  }, [t.palette, t.density, t.lang, t.fontPair, isAr]);

  return (
    <div>
      <Nav c={c} />
      <Hero t={t} c={c} />
      {t.showInstall  && <InstallSection t={t} c={c} />}
      {t.showAgent    && <AgentsSection t={t} c={c} />}
      {t.showSchema   && <SchemaSection t={t} c={c} />}
      {t.showFeatures && <FeaturesSection t={t} c={c} />}
      {t.showBuilds   && <BuildsSection t={t} c={c} />}
      {t.showPricing  && <PricingSection t={t} c={c} />}
      <FooterCTA t={t} c={c} />
      <Footer t={t} c={c} />

      <TweaksPanel>
        <TweakSection label="Palette" />
        <TweakColor
          label="Accent"
          value={t.palette}
          options={Object.values(PALETTES)}
          onChange={(v) => {
            const name = Object.keys(PALETTES).find(k => PALETTES[k] === v || PALETTES[k][0] === v[0]) || "Custom";
            setTweak({ palette: v, accentName: name });
          }}
        />
        <div style={{ fontSize: 10.5, color: "rgba(41,38,27,.55)", textAlign: "center", marginTop: -4 }}>
          {t.accentName || "Saudi green"}
        </div>

        <TweakSection label="Typography" />
        <TweakSelect
          label="Type system"
          value={t.fontPair}
          options={[
            { value: "geist",  label: "Geist (sans + mono)" },
            { value: "mono",   label: "All monospace" },
            { value: "arabic", label: "Reem Kufi (Arabic display)" },
          ]}
          onChange={(v) => setTweak("fontPair", v)}
        />

        <TweakSection label="Language" />
        <TweakRadio
          label="Locale"
          value={t.lang}
          options={[
            { value: "en", label: "EN" },
            { value: "ar", label: "AR" },
          ]}
          onChange={(v) => setTweak("lang", v)}
        />

        <TweakSection label="Hero copy" />
        <TweakSelect
          label="Headline"
          value={t.heroCopy}
          options={[
            { value: "default",   label: "One prompt. Live in seconds." },
            { value: "speed",     label: "Deploy at the speed of thought." },
            { value: "agents",    label: "Built for agents." },
            { value: "bilingual", label: "يلا — ship it." },
          ]}
          onChange={(v) => setTweak("heroCopy", v)}
        />

        <TweakSection label="Layout" />
        <TweakRadio
          label="Density"
          value={t.density}
          options={["compact", "regular", "roomy"]}
          onChange={(v) => setTweak("density", v)}
        />

        <TweakSection label="Demo" />
        <TweakSlider
          label="Terminal speed"
          value={t.demoSpeed}
          min={0.5} max={3} step={0.25}
          onChange={(v) => setTweak("demoSpeed", v)}
          unit="x"
        />

        <TweakSection label="Sections" />
        <TweakToggle label="Install steps"   value={t.showInstall}  onChange={(v) => setTweak("showInstall", v)} />
        <TweakToggle label="Agents · Skills" value={t.showAgent}    onChange={(v) => setTweak("showAgent", v)} />
        <TweakToggle label="JSON schema"     value={t.showSchema}   onChange={(v) => setTweak("showSchema", v)} />
        <TweakToggle label="Feature grid"    value={t.showFeatures} onChange={(v) => setTweak("showFeatures", v)} />
        <TweakToggle label="Build types"     value={t.showBuilds}   onChange={(v) => setTweak("showBuilds", v)} />
        <TweakToggle label="Pricing"         value={t.showPricing}  onChange={(v) => setTweak("showPricing", v)} />
      </TweaksPanel>
    </div>
  );
}

// ─── helpers ─────────────────────────────────────────────────────────
function hexToRgba(hex, a) {
  if (!hex || !hex.startsWith("#")) return `rgba(0,196,122,${a})`;
  const h = hex.replace("#", "");
  const v = h.length === 3
    ? h.split("").map(c => parseInt(c + c, 16))
    : [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
  return `rgba(${v[0]},${v[1]},${v[2]},${a})`;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
