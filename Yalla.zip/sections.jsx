// sections.jsx — all body sections after the hero

// ─── Agents section ─────────────────────────────────────────────────
const AgentsSection = ({ t, c }) => {
  const isAr = t.lang === "ar";
  return (
    <section id="agents" className="section" style={{ position: "relative" }}>
      <div className="wrap">
        <div className={isAr ? "rtl" : ""} style={{ maxWidth: 760, marginBottom: 56 }}>
          <span className="eyebrow lang-body">{c.agents_eyebrow}</span>
          <h2 className="h1 lang-body" style={{ marginTop: 18 }}>{c.agents_title}</h2>
          <p className="lang-body" style={{ fontSize: 17, marginTop: 16, maxWidth: 640 }}>
            {c.agents_sub}
          </p>
        </div>

        <div className="split-grid split-agents">
          {/* Left: skill discovery */}
          <div className="card" style={{ padding: 0, overflow: "hidden", display: "flex", flexDirection: "column" }}>
            <div style={{ padding: "24px 28px 18px", borderBottom: "1px solid var(--border)" }}>
              <div className="pill accent">SKILLS</div>
              <h3 className="lang-body" style={{ fontSize: 22, marginTop: 14, letterSpacing: "-0.01em" }}>
                {c.skills_title}
              </h3>
              <p className="lang-body" style={{ fontSize: 14.5, marginTop: 8, color: "var(--fg-2)" }}>
                {c.skills_body}
              </p>
            </div>
            <div style={{ padding: 22, flex: 1, direction: "ltr", position: "relative" }}>
              <CopyButton
                value={`> yalla skills get deploy

{
  "skill": "deploy",
  "summary": "Build & ship a service",
  "inputs": {
    "git":      { "type": "url", "required": true },
    "build":    { "enum": ["dockerfile","nixpacks","railpack",
                           "buildpacks","static","image"] },
    "region":   { "enum": ["jed-1","ruh-1","dxb-1","fra-1"] },
    "env":      { "type": "kv", "required": false },
    "replicas": { "type": "int", "min": 1, "max": 64 },
    "health":   { "type": "string" }
  },
  "errors": ["auth","quota","build","runtime"],
  "no_input": true
}`}
                label="copy"
              />
              <pre className="mono" style={{
                margin: 0, fontSize: 12.5, lineHeight: 1.7, color: "var(--fg-2)",
              }}>
{`> yalla skills get deploy`}
{"\n"}
{`{
  "skill": "deploy",
  "summary": "Build & ship a service",
  "inputs": {
    "git":      { "type": "url", "required": true },
    "build":    { "enum": ["dockerfile","nixpacks","railpack",
                           "buildpacks","static","image"] },
    "region":   { "enum": ["jed-1","ruh-1","dxb-1","fra-1"] },
    "env":      { "type": "kv", "required": false },
    "replicas": { "type": "int", "min": 1, "max": 64 },
    "health":   { "type": "string" }
  },
  "errors": ["auth","quota","build","runtime"],
  "no_input": true
}`}
              </pre>
            </div>
          </div>

          {/* Right column: two stacked cards */}
          <div className="agents-right">
            <div className="card" style={{ padding: "24px 28px" }}>
              <div className="pill" style={{ borderColor: "rgba(167,139,250,0.3)", color: "var(--violet)", background: "rgba(167,139,250,0.08)" }}>
                JSON
              </div>
              <h3 className="lang-body" style={{ fontSize: 22, marginTop: 14 }}>{c.json_title}</h3>
              <p className="lang-body" style={{ fontSize: 14.5, marginTop: 8, color: "var(--fg-2)" }}>
                {c.json_body}
              </p>
              <div style={{ marginTop: 18, direction: "ltr" }}>
                <div style={{
                  display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10,
                }}>
                  <ExitCode code="0" label="ok" tone="ok" />
                  <ExitCode code="2" label="invalid_args" tone="warn" />
                  <ExitCode code="3" label="auth" tone="warn" />
                  <ExitCode code="4" label="quota" tone="warn" />
                  <ExitCode code="5" label="build" tone="err" />
                  <ExitCode code="6" label="runtime" tone="err" />
                </div>
              </div>
            </div>

            <div className="card" style={{ padding: "24px 28px", flex: 1 }}>
              <div className="pill" style={{ borderColor: "rgba(103,232,249,0.3)", color: "var(--cyan)", background: "rgba(103,232,249,0.08)" }}>
                INTROSPECTION
              </div>
              <h3 className="lang-body" style={{ fontSize: 22, marginTop: 14 }}>{c.schema_title}</h3>
              <p className="lang-body" style={{ fontSize: 14.5, marginTop: 8, color: "var(--fg-2)" }}>
                {c.schema_body}
              </p>
              <div style={{ marginTop: 18, direction: "ltr" }}>
                <CopyBlock
                  dense
                  lines={[
                    { prompt: "$", cmd: "yalla describe", arg: "--commands" },
                    { prompt: "$", cmd: "yalla describe", arg: "--errors --regions" },
                    { prompt: "$", cmd: "yalla schema deploy", arg: "--json" },
                  ]}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const ExitCode = ({ code, label, tone }) => {
  const colorMap = {
    ok:   "var(--accent)",
    warn: "var(--amber)",
    err:  "var(--rose)",
  };
  return (
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "8px 10px",
      border: "1px solid var(--border)",
      borderRadius: 8,
      background: "rgba(255,255,255,0.02)",
    }}>
      <span style={{
        fontFamily: "var(--mono)", fontSize: 14, fontWeight: 600,
        color: colorMap[tone], minWidth: 18,
      }}>{code}</span>
      <span style={{ fontFamily: "var(--mono)", fontSize: 12, color: "var(--fg-2)" }}>{label}</span>
    </div>
  );
};

// ─── Build types ────────────────────────────────────────────────────
const BuildsSection = ({ t, c }) => {
  const isAr = t.lang === "ar";
  const builds = [
    { name: "Dockerfile",       hint: "Bring your own image recipe",   icon: "▢" },
    { name: "Nixpacks",         hint: "Auto-detect & build",            icon: "◇" },
    { name: "Railpack",         hint: "Layered builds, cached",         icon: "▤" },
    { name: "Heroku Buildpacks",hint: "Drop-in compatibility",          icon: "◐" },
    { name: "Paketo Buildpacks",hint: "Cloud-native standard",          icon: "◑" },
    { name: "Static",           hint: "Just files. Globally cached.",   icon: "≡" },
    { name: "Pre-built",        hint: "Ship an artifact",               icon: "⊟" },
    { name: "Container Image",  hint: "Any registry, any tag",          icon: "▦" },
  ];
  return (
    <section className="section" style={{ paddingTop: 60 }}>
      <div className="wrap">
        <div className={isAr ? "rtl" : ""} style={{ display: "flex", justifyContent: "space-between", alignItems: "end", flexWrap: "wrap", gap: 24, marginBottom: 40 }}>
          <div style={{ maxWidth: 620 }}>
            <span className="eyebrow lang-body">{c.builds_eyebrow}</span>
            <h2 className="h2 lang-body" style={{ marginTop: 16 }}>{c.builds_title}</h2>
            <p className="lang-body" style={{ marginTop: 12, fontSize: 16 }}>{c.builds_sub}</p>
          </div>
          <div className="row gap-12">
            {["Web apps", "APIs", "Workers", "Static", "Cron"].map(k => (
              <span key={k} className="pill lang-body">{k}</span>
            ))}
          </div>
        </div>

        <div style={{
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 10,
        }} className="builds-grid">
          {builds.map(b => (
            <div key={b.name} className="card" style={{ padding: 18, minHeight: 110 }}>
              <div style={{
                display: "flex", alignItems: "center", justifyContent: "space-between"
              }}>
                <span className="mono" style={{ fontSize: 22, color: "var(--accent)" }}>{b.icon}</span>
                <span className="mono" style={{ fontSize: 11, color: "var(--fg-3)" }}>·build</span>
              </div>
              <div className="lang-body" style={{ marginTop: 16, fontSize: 14.5, fontWeight: 500 }}>{b.name}</div>
              <div className="lang-body" style={{ marginTop: 4, fontSize: 12.5, color: "var(--fg-3)" }}>{b.hint}</div>
            </div>
          ))}
        </div>
      </div>
      <style>{`
        @media (max-width: 900px) {
          .builds-grid { grid-template-columns: repeat(2, 1fr) !important; }
        }
      `}</style>
    </section>
  );
};

// ─── Schema deep-dive ──────────────────────────────────────────────────
const SchemaSection = ({ t, c }) => {
  const isAr = t.lang === "ar";
  return (
    <section className="section" style={{ paddingTop: 60 }}>
      <div className="wrap">
        <div className="card" style={{
          padding: 0, overflow: "hidden",
          background:
            "radial-gradient(ellipse 80% 60% at 20% 0%, rgba(0,196,122,0.08), transparent 60%), var(--bg-1)",
        }}>
          <div className="split-grid split-schema">
            <div className={isAr ? "rtl" : ""} style={{ padding: "48px 44px" }}>
              <span className="eyebrow lang-body">RFC-grade contracts</span>
              <h2 className="h2 lang-body" style={{ marginTop: 16 }}>
                {isAr ? "أوامر يقرأها الإنسان والوكيل." : "Commands humans and agents both read."}
              </h2>
              <p className="lang-body" style={{ marginTop: 14, fontSize: 15.5, maxWidth: 480 }}>
                {isAr
                  ? "كل أمر له مخطط، وكل خطأ له كود، وكل خروج له معنى ثابت. ابنِ خطوط نشر تثق بها — وكلاء أو بشر."
                  : "Every command has a schema. Every error has a code. Every exit has stable meaning. Build pipelines you trust — agent or human."}
              </p>
              <ul className="lang-body" style={{
                listStyle: "none", padding: 0, margin: "26px 0 0",
                display: "flex", flexDirection: "column", gap: 12,
                fontSize: 14, color: "var(--fg-2)",
              }}>
                <Bullet>Stable exit codes — your CI never guesses</Bullet>
                <Bullet>Typed errors — JSON shape never drifts</Bullet>
                <Bullet>No-input mode — never waits for a TTY</Bullet>
                <Bullet>Streaming JSON — pipe straight into anything</Bullet>
              </ul>
            </div>
            <div style={{
              borderLeft: "1px solid var(--border)",
              padding: 24,
              background: "#050505",
              direction: "ltr",
              position: "relative",
            }}>
              <CopyButton
                value={`yalla deploy --git ./shop --build nixpacks --json
{
  "id": "dep_3f8a1c",
  "status": "live",
  "url": "https://shop.yalla.sa",
  "region": "jed-1",
  "build": {
    "type": "nixpacks",
    "duration_ms": 12348,
    "image": "yalla/dep_3f8a1c:sha-9b2"
  },
  "replicas": 2,
  "health": "passing",
  "logs": "yalla logs dep_3f8a1c --follow"
}`}
                label="copy"
              />
              <pre className="mono" style={{ margin: 0, fontSize: 12.5, lineHeight: 1.75, overflow: "auto" }}>
<span className="c-prompt">$ </span><span className="c-cmd">yalla deploy --git ./shop --build nixpacks --json</span>{"\n"}
<span className="c-dim">{"{"}</span>{"\n"}
<span className="c-key">  "id":</span> <span className="c-str">"dep_3f8a1c"</span>,{"\n"}
<span className="c-key">  "status":</span> <span className="c-ok">"live"</span>,{"\n"}
<span className="c-key">  "url":</span> <span className="c-str">"https://shop.yalla.sa"</span>,{"\n"}
<span className="c-key">  "region":</span> <span className="c-str">"jed-1"</span>,{"\n"}
<span className="c-key">  "build":</span> <span className="c-dim">{"{"}</span>{"\n"}
<span className="c-key">    "type":</span> <span className="c-str">"nixpacks"</span>,{"\n"}
<span className="c-key">    "duration_ms":</span> <span className="c-info">12348</span>,{"\n"}
<span className="c-key">    "image":</span> <span className="c-str">"yalla/dep_3f8a1c:sha-9b2"</span>{"\n"}
<span className="c-dim">  {"}"}</span>,{"\n"}
<span className="c-key">  "replicas":</span> <span className="c-info">2</span>,{"\n"}
<span className="c-key">  "health":</span> <span className="c-ok">"passing"</span>,{"\n"}
<span className="c-key">  "logs":</span> <span className="c-str">"yalla logs dep_3f8a1c --follow"</span>{"\n"}
<span className="c-dim">{"}"}</span>{"\n"}
{"\n"}
<span className="c-dim"># exit 0</span>
              </pre>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const Bullet = ({ children }) => (
  <li style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
    <span style={{
      width: 14, height: 14, borderRadius: 999,
      border: "1px solid var(--accent-line)", display: "inline-flex",
      alignItems: "center", justifyContent: "center", marginTop: 3,
      flexShrink: 0,
    }}>
      <span style={{ width: 6, height: 6, borderRadius: 999, background: "var(--accent)" }}></span>
    </span>
    <span>{children}</span>
  </li>
);

Object.assign(window, { AgentsSection, BuildsSection, SchemaSection });
